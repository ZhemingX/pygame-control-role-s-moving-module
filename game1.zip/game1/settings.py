class Settings(object):
    """dosctring for Settings"""
    """for screen setting"""
    def __init__(self):
        self.screen_width = 1200
        self.screen_height = 800
        self.bg_color = (0,0,0)
        self.role_speed_factor = 1