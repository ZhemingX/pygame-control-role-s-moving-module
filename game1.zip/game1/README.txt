This project is just for being familiar with .pygame library which is designed for creating simple games.
In the project I created a role called Luna, a female character in the popular MOBA game Wang Zhe Rong Yao,
and the user could controlled her moving on the black screen.

The basic operation:
W-up A-left S-down D-right X-stay still

To run this game, type this command in the terminal:
python3 run_game.py

This model is just a prototype, thus you would feel boring since I haven't added any other operations like
releasing skills, enemy attack except moving. I will add these when I have passion hhh....
But you can refer to this basic model as a framework for role's moving in your own game.

Happy Everyday!


